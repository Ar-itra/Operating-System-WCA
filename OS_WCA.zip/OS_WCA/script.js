
"use strict";

document.addEventListener("DOMContentLoaded", () => {
    const $ = id => document.getElementById(id);

    const processTable = $("processTable");
    const algorithmSelect = $("algorithm");
    const quantumField = $("quantumField");
    const quantumInput = $("quantum");
    const resultsSection = $("results");
    const message = $("message");

    const colors = [
        "#a9dbe8", "#b9b2ff", "#a9dfc4", "#ffd49a",
        "#f3b5ce", "#a9c8f5", "#d8b5f5", "#c5d9a7"
    ];

    function showMessage(text = "") {
        message.textContent = text;
    }

    function clearResults() {
        resultsSection.hidden = true;
        showMessage();
    }

    function addProcess(arrival = 0, burst = 4, priority = 1) {
        const id = `P${processTable.rows.length + 1}`;
        const row = document.createElement("tr");

        const idCell = document.createElement("td");
        idCell.className = "pid";
        idCell.textContent = id;
        row.appendChild(idCell);

        function inputCell(className, value, label, min) {
            const cell = document.createElement("td");
            const input = document.createElement("input");

            input.type = "number";
            input.min = String(min);
            input.step = "1";
            input.value = String(value);
            input.className = className;
            input.setAttribute("aria-label", label);
            input.addEventListener("input", clearResults);

            cell.appendChild(input);
            return cell;
        }

        row.appendChild(inputCell(
            "arrival", arrival, `${id} arrival time`, 0
        ));
        row.appendChild(inputCell(
            "burst", burst, `${id} burst time`, 1
        ));
        row.appendChild(inputCell(
            "priority", priority, `${id} priority`, 1
        ));

        const actionCell = document.createElement("td");
        actionCell.className = "no-print";

        const removeButton = document.createElement("button");
        removeButton.type = "button";
        removeButton.className = "btn delete-btn";
        removeButton.textContent = "Remove";

        removeButton.addEventListener("click", () => {
            row.remove();
            renumberProcesses();
            clearResults();
        });

        actionCell.appendChild(removeButton);
        row.appendChild(actionCell);

        processTable.appendChild(row);
        clearResults();
    }

    function renumberProcesses() {
        [...processTable.rows].forEach((row, index) => {
            const id = `P${index + 1}`;
            row.querySelector(".pid").textContent = id;

            ["arrival", "burst", "priority"].forEach(className => {
                row.querySelector(`.${className}`).setAttribute(
                    "aria-label", `${id} ${className}`
                );
            });
        });
    }

    function loadProcesses(data) {
        processTable.replaceChildren();
        data.forEach(p => addProcess(p.arrival, p.burst, p.priority));
        clearResults();
    }

    function readProcesses() {
        const rows = [...processTable.rows];

        if (!rows.length) {
            throw new Error("Please add at least one process.");
        }

        return rows.map((row, index) => {
            const arrival = Number(row.querySelector(".arrival").value);
            const burst = Number(row.querySelector(".burst").value);
            const priority = Number(row.querySelector(".priority").value);

            if (
                !Number.isSafeInteger(arrival) ||
                !Number.isSafeInteger(burst) ||
                !Number.isSafeInteger(priority) ||
                arrival < 0 || burst < 1 || priority < 1
            ) {
                throw new Error(
                    `Invalid values for P${index + 1}. ` +
                    "Arrival must be >= 0; burst and priority must be >= 1. " +
                    "Use whole numbers."
                );
            }

            return {
                id: `P${index + 1}`,
                arrival,
                burst,
                priority,
                remaining: burst,
                completion: 0,
                turnaround: 0,
                waiting: 0,
                order: index,
                color: colors[index % colors.length]
            };
        });
    }

    function addSegment(segments, process, start, end) {
        if (end <= start) return;

        segments.push({
            id: process ? process.id : "IDLE",
            start,
            end,
            color: process ? process.color : "#cfd3d3"
        });
    }

    // First Come, First Served
    function fcfs(processes) {
        const queue = [...processes].sort(
            (a, b) => a.arrival - b.arrival || a.order - b.order
        );

        const segments = [];
        let time = 0;

        for (const p of queue) {
            if (time < p.arrival) {
                addSegment(segments, null, time, p.arrival);
                time = p.arrival;
            }

            const start = time;
            time += p.burst;
            p.completion = time;

            addSegment(segments, p, start, time);
        }

        return segments;
    }

    // Shortest Job First, non-preemptive
    function sjf(processes) {
        const pending = [...processes];
        const segments = [];
        let time = 0;

        while (pending.length) {
            const ready = pending
                .filter(p => p.arrival <= time)
                .sort((a, b) =>
                    a.burst - b.burst ||
                    a.arrival - b.arrival ||
                    a.order - b.order
                );

            if (!ready.length) {
                const next = Math.min(...pending.map(p => p.arrival));
                addSegment(segments, null, time, next);
                time = next;
                continue;
            }

            const p = ready[0];
            const start = time;

            time += p.burst;
            p.completion = time;

            addSegment(segments, p, start, time);
            pending.splice(pending.indexOf(p), 1);
        }

        return segments;
    }

    // Priority Scheduling, non-preemptive.
    // Lower number means higher priority.
    function priorityScheduling(processes) {
        const pending = [...processes];
        const segments = [];
        let time = 0;

        while (pending.length) {
            const ready = pending
                .filter(p => p.arrival <= time)
                .sort((a, b) =>
                    a.priority - b.priority ||
                    a.arrival - b.arrival ||
                    a.order - b.order
                );

            if (!ready.length) {
                const next = Math.min(...pending.map(p => p.arrival));
                addSegment(segments, null, time, next);
                time = next;
                continue;
            }

            const p = ready[0];
            const start = time;

            time += p.burst;
            p.completion = time;

            addSegment(segments, p, start, time);
            pending.splice(pending.indexOf(p), 1);
        }

        return segments;
    }

    // Round Robin, preemptive
    function roundRobin(processes, quantum) {
        const queue = [...processes].sort(
            (a, b) => a.arrival - b.arrival || a.order - b.order
        );

        const ready = [];
        const segments = [];

        let time = 0;
        let index = 0;
        let finished = 0;

        while (finished < queue.length) {
            while (
                index < queue.length &&
                queue[index].arrival <= time
            ) {
                ready.push(queue[index++]);
            }

            if (!ready.length) {
                const next = queue[index].arrival;
                addSegment(segments, null, time, next);
                time = next;
                continue;
            }

            const p = ready.shift();
            const start = time;
            const duration = Math.min(quantum, p.remaining);

            time += duration;
            p.remaining -= duration;

            addSegment(segments, p, start, time);

            // Add newly arrived processes before re-queuing P.
            while (
                index < queue.length &&
                queue[index].arrival <= time
            ) {
                ready.push(queue[index++]);
            }

            if (p.remaining > 0) {
                ready.push(p);
            } else {
                p.completion = time;
                finished++;
            }
        }

        return segments;
    }

    function calculateMetrics(processes) {
        let waitingSum = 0;
        let turnaroundSum = 0;

        processes.forEach(p => {
            p.turnaround = p.completion - p.arrival;
            p.waiting = p.turnaround - p.burst;

            waitingSum += p.waiting;
            turnaroundSum += p.turnaround;
        });

        return {
            avgWaiting: waitingSum / processes.length,
            avgTurnaround: turnaroundSum / processes.length,
            totalTime: Math.max(...processes.map(p => p.completion))
        };
    }

    function drawGantt(segments) {
        const chart = $("ganttChart");
        chart.replaceChildren();

        if (!segments.length) return;

        const total = segments[segments.length - 1].end;
        if (total <= 0) return;

        const ids = [
            ...new Set(
                segments.filter(s => s.id !== "IDLE").map(s => s.id)
            )
        ];

        if (segments.some(s => s.id === "IDLE")) {
            ids.push("IDLE");
        }

        const inner = document.createElement("div");
        inner.className = "gantt-inner";

        const legend = document.createElement("div");
        legend.className = "gantt-legend";

        [
            ["Idle Time", "#cfd3d3"],
            ["CPU Time", "#a9dbe8"]
        ].forEach(([label, color]) => {
            const item = document.createElement("span");
            item.className = "legend-item";

            const swatch = document.createElement("span");
            swatch.className = "legend-color";
            swatch.style.backgroundColor = color;

            const text = document.createElement("span");
            text.textContent = label;

            item.append(swatch, text);
            legend.appendChild(item);
        });

        inner.appendChild(legend);

        const rawStep = total / 8;
        const magnitude = Math.pow(
            10, Math.floor(Math.log10(Math.max(1, rawStep)))
        );
        const normalized = rawStep / magnitude;
        const multiplier =
            normalized <= 1 ? 1 :
            normalized <= 2 ? 2 :
            normalized <= 5 ? 5 : 10;

        const step = multiplier * magnitude;
        const tickCount = Math.ceil(total / step);

        const plot = document.createElement("div");
        plot.className = "gantt-plot";
        plot.style.setProperty("--grid-step", `${step / total * 100}%`);

        const yTitle = document.createElement("div");
        yTitle.className = "gantt-y-title";
        yTitle.textContent = "Processes";
        plot.appendChild(yTitle);

        ids.forEach(id => {
            const row = document.createElement("div");
            row.className = "gantt-row";

            const label = document.createElement("span");
            label.className = "gantt-row-label";
            label.textContent = id;
            row.appendChild(label);

            segments.filter(s => s.id === id).forEach(segment => {
                const bar = document.createElement("div");
                bar.className = "gantt-bar";

                bar.style.left = `${segment.start / total * 100}%`;
                bar.style.width =
                    `${(segment.end - segment.start) / total * 100}%`;
                bar.style.backgroundColor = segment.color;
                bar.title = `${id}: ${segment.start} to ${segment.end}`;

                row.appendChild(bar);
            });

            plot.appendChild(row);
        });

        inner.appendChild(plot);

        const axis = document.createElement("div");
        axis.className = "gantt-axis";

        for (let i = 0; i <= tickCount; i++) {
            const time = Math.min(i * step, total);
            const tick = document.createElement("span");

            tick.className = "gantt-tick";
            tick.textContent = Number(time.toFixed(2));
            tick.style.left = `${time / total * 100}%`;

            axis.appendChild(tick);
        }

        inner.appendChild(axis);

        const axisTitle = document.createElement("div");
        axisTitle.className = "gantt-axis-title";
        axisTitle.textContent = "Time (units)";
        inner.appendChild(axisTitle);

        chart.appendChild(inner);
    }

    function displayResults(processes, segments, metrics, name) {
        $("algorithmName").textContent = `${name} completed successfully.`;
        $("avgWaiting").textContent = metrics.avgWaiting.toFixed(2);
        $("avgTurnaround").textContent = metrics.avgTurnaround.toFixed(2);
        $("totalTime").textContent = metrics.totalTime;

        const resultTable = $("resultTable");
        resultTable.replaceChildren();

        [...processes]
            .sort((a, b) => a.order - b.order)
            .forEach(p => {
                const row = document.createElement("tr");

                [
                    p.id,
                    p.arrival,
                    p.burst,
                    p.priority,
                    p.completion,
                    p.turnaround,
                    p.waiting
                ].forEach(value => {
                    const cell = document.createElement("td");
                    cell.textContent = String(value);
                    row.appendChild(cell);
                });

                resultTable.appendChild(row);
            });

        drawGantt(segments);

        const steps = $("executionSteps");
        steps.replaceChildren();

        segments.forEach((s, index) => {
            const item = document.createElement("li");
            item.textContent =
                `${index + 1}. ${s.id} executes from ${s.start} to ${s.end}.`;
            steps.appendChild(item);
        });

        resultsSection.hidden = false;
    }

    function runSimulation() {
        clearResults();

        try {
            const processes = readProcesses();
            const algorithm = algorithmSelect.value;
            let segments;
            let name;

            switch (algorithm) {
                case "fcfs":
                    name = "FCFS";
                    segments = fcfs(processes);
                    break;

                case "sjf":
                    name = "SJF (Non-preemptive)";
                    segments = sjf(processes);
                    break;

                case "priority":
                    name = "Priority (Non-preemptive)";
                    segments = priorityScheduling(processes);
                    break;

                case "rr": {
                    const quantum = Number(quantumInput.value);

                    if (
                        !Number.isSafeInteger(quantum) ||
                        quantum < 1
                    ) {
                        throw new Error(
                            "Time quantum must be a positive integer."
                        );
                    }

                    name = `Round Robin (Quantum = ${quantum})`;
                    segments = roundRobin(processes, quantum);
                    break;
                }

                default:
                    throw new Error("Please select a valid algorithm.");
            }

            const metrics = calculateMetrics(processes);
            displayResults(processes, segments, metrics, name);
            showMessage();
        } catch (error) {
            showMessage(error.message);
        }
    }

    $("addBtn").addEventListener("click", () => {
        addProcess();
    });

    $("runBtn").addEventListener("click", runSimulation);

    $("sampleBtn").addEventListener("click", () => {
        loadProcesses([
            { arrival: 0, burst: 5, priority: 2 },
            { arrival: 1, burst: 3, priority: 1 },
            { arrival: 2, burst: 8, priority: 3 },
            { arrival: 3, burst: 6, priority: 2 }
        ]);
    });

    $("resetBtn").addEventListener("click", () => {
        algorithmSelect.value = "fcfs";
        quantumInput.value = "2";
        quantumField.hidden = true;

        loadProcesses([
            { arrival: 0, burst: 5, priority: 2 },
            { arrival: 1, burst: 3, priority: 1 },
            { arrival: 2, burst: 8, priority: 3 }
        ]);
    });

    algorithmSelect.addEventListener("change", () => {
        quantumField.hidden = algorithmSelect.value !== "rr";
        clearResults();
    });

    quantumInput.addEventListener("input", clearResults);

    $("printBtn").addEventListener("click", () => {
        if (resultsSection.hidden || !$("ganttChart").children.length) {
            showMessage("Please run the simulation before printing.");
            return;
        }

        // Wait for the updated chart to render before print preview.
        requestAnimationFrame(() => {
            requestAnimationFrame(() => window.print());
        });
    });

    // Start with three editable sample processes.
    loadProcesses([
        { arrival: 0, burst: 5, priority: 2 },
        { arrival: 1, burst: 3, priority: 1 },
        { arrival: 2, burst: 8, priority: 3 }
    ]);
});
